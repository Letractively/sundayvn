// UK lang variables
