// EN lang variables
