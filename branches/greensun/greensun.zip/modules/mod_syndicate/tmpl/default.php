<?php // no direct access
defined('_JEXEC') or die('Restricted access'); ?>
<a href="<?php echo $link ?>">
	<?php echo JHTML::_('image.site', 'livemarks.png', '/images/M_images/', NULL, NULL, 'feed-image'); ?> <span><?php echo $params->get('text') ?></span></a>