<?php
/**
* ------------------------------------------------------------------------------------
* @package JoloSlider
* Site: www.themexpert.com
* Email: themexpert@gmail.com
* @copyright Copyright (C) 2010 ThemeXpert. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* @version 1.1
* ------------------------------------------------------------------------------------
* This Slideshow based on Nivo Slider Js Script form http://dev7studios.com .
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class modJoloSliderHelper{
    
    function getList(&$params, $catid){
        
        global $mainframe;
        //Initialize param settings
        $count              = $params->get('article_count',4); 
        $image_source       = $params->get('image_source','joomla');        
        $show_front        = $params->get('show_front', 1);
        $num_charecter      = $params->get('introtext_charecter_limit',50);
        $cparams    =& $mainframe->getParams('com_content');

        $db         =& JFactory::getDBO();
        $user       =& JFactory::getUser();
        $userId     = (int) $user->get('id');
        $aid        = $user->get('aid', 0);
   
        $contentConfig  = &JComponentHelper::getParams( 'com_content' );

        $nullDate        = $db->getNullDate();
        $date =& JFactory::getDate();
        $now = $date->toMySQL();
        $where = '';
        
        if($image_source == 'joomla'){
                   
            if($show_front != 2){
                if( $catid ) {
                    $catCondition .= ' AND a.catid IN ('.$catid.') ';
                }    
            }
            // Content Items only
                $query  = 'SELECT a.*,
                    cc.description as catdesc, cc.title as cattitle,s.description as secdesc, s.title as sectitle,' .
                    ' CASE WHEN CHAR_LENGTH(a.alias) THEN CONCAT_WS(":", a.id, a.alias) ELSE a.id END as slug,'.
                    ' CASE WHEN CHAR_LENGTH(cc.alias) THEN CONCAT_WS(":",cc.id,cc.alias) ELSE cc.id END as catslug,'.
                    ' CASE WHEN CHAR_LENGTH(s.alias) THEN CONCAT_WS(":", s.id, s.alias) ELSE s.id END as secslug'. 
                    "\n FROM #__content AS a".
                    ($show_front == '0' ? ' LEFT JOIN #__content_frontpage AS f ON f.content_id = a.id' : '') .
                    ($show_front == '2' ? ' INNER JOIN #__content_frontpage AS f ON f.content_id = a.id' : '') .
                    ' INNER JOIN #__categories AS cc ON cc.id = a.catid' .
                    ' INNER JOIN #__sections AS s ON s.id = a.sectionid'.
                    "\n WHERE a.state = 1". 
                    ($catid && $show_front != 2 ? $catCondition : '').
                    ($show_front == '0' ? ' AND f.content_id IS NULL ' : '').
                    "\n AND ( a.publish_up = " . $db->Quote( $db->getNullDate() ) . " OR a.publish_up <= " . $db->Quote( $now  ) . " )".                    "\n AND ( a.publish_down = " . $db->Quote( $db->getNullDate() ) . " OR a.publish_down >= " . $db->Quote( $now  ) . " )"
                    . ( ( !$mainframe->getCfg( 'shownoauth' ) ) ? "\n AND a.access <= " . (int) $aid : '' )
                    ;
                    
                                   
            // order by 
            if( $params->get('sort_order_field', 'created') != "random" ){
                $orderBy = "a." . $params->get('sort_order_field', 'created') . ' ' . $params->get('sort_order', 'DESC');
            } else {
                $orderBy = " RAND() ";
            }
            $query .= ' ORDER BY ' . $orderBy;
            
            //echo $query;
            // end Joomla specific
        }
        else if ($image_source == 'image_dir'){
            return modJoloSliderHelper::loadImagesFromDir($params);
        }
                
        $db->setQuery($query, 0, $count);
        $rows = $db->loadObjectList();
        $i=0;
        $lists    = array();

        if(is_array($rows) && count($rows)>0){
            foreach($rows as $row){
                $text = JHTML::_('content.prepare',$row->introtext,$cparams);
                $lists[$i]->id = $row->id;
                $lists[$i]->created = $row->created;
                $lists[$i]->modified = $row->modified;
                $lists[$i]->title = htmlspecialchars( $row->title );
                $lists[$i]->introtext = modJoloSliderHelper::prepareText($row->introtext, $num_charecter);
                
                if ($image_source =='joomla') {
                    $lists[$i]->link = JRoute::_(ContentHelperRoute::getArticleRoute($row->slug, $row->catslug, $row->sectionid));
                    $images = modJoloSliderHelper::getImages($row->introtext);
                } else {
                    // TODO: get link and images for k2. this featrue will add on v2.
                }
                $lists[$i]->image = $images->image;
                $i++;
            }
        }
        return $lists;
    }    
    
    function prepareText($text, $num_charecter){
        $text = strip_tags($text);
        
        if(strlen($text)>$num_charecter && $num_charecter!=0){
            $text1 = substr ($text, 0, $num_charecter) . "....";
            return $text1;
        }
        else return $text;
        
        
    }
    function getImages($text) {      
        
        preg_match("/\<img.+?src=\"(.+?)\".+?\/>/", $text, $matches);        
        
        $images = new stdClass();
        $images->image = false;

        $paths = array();
        
        if (isset($matches[1])) {
            $image_path = $matches[1];

            //joomla 1.5 only
            $full_url = JURI::base();
            
            //remove any protocol/site info from the image path
            $parsed_url = parse_url($full_url);
            $paths[] = $full_url;
            if (isset($parsed_url['path']) && $parsed_url['path'] != "/") $paths[] = $parsed_url['path'];

            foreach ($paths as $path) {
                if (strpos($image_path,$path) !== false) {
                    $image_path = substr($image_path,strpos($image_path, $path)+strlen($path));
                }
            }
            
            // remove any / that begins the path
            if (substr($image_path, 0 , 1) == '/') $image_path = substr($image_path, 1);
            
            //if after removing the uri, still has protocol then the image
            //is remote and we don't support thumbs for external images
            if (strpos($image_path,'http://') !== false ||
                strpos($image_path,'https://') !== false) {
                return false;
            }
            
            $images->image = JURI::Root(True)."/".$image_path;   
        } 
        return $images;
    }
    
    function loadImagesFromDir($params){
        $josLiveSite = JURI::base();
        
        $image_dir = $params->get('image_dir');
        $display = $params->get('display');
    
        $imageIndex = array();
        foreach(glob("$image_dir/*") as $img){
            array_push($imageIndex, $img);
        }        
        //re-arrange imageIndex array according to display settings
        ($display=='random')? shuffle($imageIndex) : sort($imageIndex);
        
        return $imageIndex;   
    }
    
    /**
     * load css files: processing override css
     */     
    function loadCss( $params ){
    
        global $mainframe;
        
        $document =& JFactory::getDocument();
        
        //get all params
        $caption_background = $params->get('caption_background','#000');
        $caption_position   = $params->get('caption_position','bottom');
        $caption_width      = $params->get('caption_width','auto');
        $thumb_v_position   = $params->get('thumb_v_position','bottom');
        $thumb_h_position   = $params->get('thumb_h_position','right');
        $thumb_style        = ($params->get('thumb_style',1) == 1) ? 'inline' : 'block';
        $thumb_width        = $params->get('thumb_width','70px');
        $thumb_height       = $params->get('thumb_height','70px');
        
        //css declaration
        $css = "
            .nivo-caption           { background: $caption_background; $caption_position : 0; width: $caption_width;}
            .nivo-controlNav        { $thumb_v_position: 0; $thumb_h_position: 0;}
            .nivo-controlNav img    { display: $thumb_style; width: $thumb_width; height: $thumb_height; }
        ";
        //css file name
        $cssFile  = 'joloslider.css';
    
        //Check css file.if it exist on template then load otherwise load default css
        if( file_exists(JPATH_SITE.DS.'templates'.DS.$mainframe->getTemplate().DS.'css'.DS.$cssFile) ) {
            $document->addStyleSheet( JURI::base().'templates/'.$mainframe->getTemplate().'/css/'.$cssFile );
        } else { 
            $document->addStyleSheet( JURI::base().'modules/mod_joloslider/assets/'.$cssFile );
        }
        $document->addStyleDeclaration($css);
    }       
    
   /**
    *   Load js
    **/
    function loadJs($params){
        JHTML::_('behavior.mootools');
        
        $document =& JFactory::getDocument();
        $module_id          = $params->get('module_id',0);
        
        $dirNav             = ($params->get('directionNav')) ? 'true' : 'false';
        $dirNavHide         = ($params->get('directionNavHide')) ? 'true' : 'false';
        $controlNav         = ($params->get('controlNav')) ? 'true' : 'false';
        $controlNavThumbs   = ($params->get('controlNavThumbs')) ? 'true' : 'false';
        $keyboardNav        = ($params->get('keyboardNav')) ? 'true' : 'false';
        $pauseOnHover       = ($params->get('pauseOnHover')) ? 'true' : 'false';
        $manualAdvance      = ($params->get('manualAdvance')) ? 'true' : 'false';
        $captionOpacity     =  $params->get('captionOpacity');
        
        $js = "
            jQuery.noConflict();
            jQuery(window).load(function() {
                setTimeout(function(){
                jQuery('#slider').nivoSlider({        
                    effect:'{$params->get('effect')}',
                    slices:{$params->get('slices')},
                    animSpeed:{$params->get('animSpeed')},
                    pauseTime:{$params->get('pauseTime')},
                    startSlide:{$params->get('startSlide')},
                    directionNav:{$dirNav},
                    directionNavHide:{$dirNavHide},
                    controlNav:{$controlNav},
                    controlNavThumbs:{$controlNavThumbs},
                    controlNavThumbsFromRel:true, 
                    keyboardNav:{$keyboardNav},
                    pauseOnHover:{$pauseOnHover},
                    manualAdvance:{$manualAdvance},
                    captionOpacity:{$captionOpacity},
                    beforeChange: function(){},
                    afterChange: function(){},
                    slideshowEnd: function(){}
                }); 
                });
            });
    ";
    
    //Load jQuery library first
    if($params->get('jqloader',1) == 1) $document->addScript('http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js');
    elseif($params->get('jqloader',1) == 2) $document->addScript(JURI::base().'modules/mod_joloslider/assets/js/jquery1.4.min.js');

    //load slider script
    $document->addScript( JURI::base().'modules/mod_joloslider/assets/js/slider.js' );
    
    //Slider options
    $document->addScriptDeclaration($js);
    }
}

?>