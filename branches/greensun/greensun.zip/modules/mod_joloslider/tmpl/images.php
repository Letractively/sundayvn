<?php
/**
* ------------------------------------------------------------------------------------
* @package JoloSlider
* Site: www.themexpert.com
* Email: themexpert@gmail.com
* @copyright Copyright (C) 2010 ThemeXpert. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* @version 1.1
* ------------------------------------------------------------------------------------
* This Slideshow based on Nivo Slider Js Script form http://dev7studios.com .
*/

defined('_JEXEC') or die('Restricted access'); 
?>

<div id="slider">
    <?php $i=1; foreach($lists as $list):?>
        <img src="<?php echo $list;?>" alt="<?php echo $i;?>" rel="<?php echo $list?>" />
    <?php $i++; endforeach;?>
</div>
