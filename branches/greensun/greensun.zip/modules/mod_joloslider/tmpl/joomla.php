<?php
/**
* ------------------------------------------------------------------------------------
* @package JoloSlider
* Site: www.themexpert.com
* Email: themexpert@gmail.com
* @copyright Copyright (C) 2010 ThemeXpert. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* @version 2.0
* ------------------------------------------------------------------------------------
* This Slideshow based on Nivo Slider Js Script form http://dev7studios.com .
*/

defined('_JEXEC') or die('Restricted access'); 
//print_r($list);
?>

<div id="slider">
    <?php foreach($lists as $list):?>
        <?php echo ($params->get('link_image')) ? '<a href="'.$list->link.'">' : '';?>
            <img src="<?php echo $list->image ;?>" alt="<?php echo $list->title;?>" title="#<?php echo $list->id;?>" rel="<?php echo $list->image ;?>" />
        <?php echo ($params->get('link_image')) ? '</a>': '' ;?> 
    <?php endforeach;?>
</div>
<?php if($show_title || $show_intro):?>
<?php foreach($lists as $list):?>
    <div id="<?php echo $list->id;?>" class="nivo-html-caption">
        <?php if($show_title):?>
            <h4>
            <?php 
                echo ($show_title_link) ? '<a href="'.$list->link.'">':''; 
                echo $list->title;
                echo ($show_title_link) ? '</a>' : ''; 
            ?>
            </h4>
        <?php endif;?>
        <?php if($show_intro):?>
            <p><?php echo $list->introtext;?></p>
        <?php endif;?>
    </div>
<?php endforeach;?>
<?php endif;?>