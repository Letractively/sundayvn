<?php
/**
* ------------------------------------------------------------------------------------
* @package JoloSlider
* Site: www.themexpert.com
* Email: themexpert@gmail.com
* @copyright Copyright (C) 2010 ThemeXpert. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* @version 1.5.1
* ------------------------------------------------------------------------------------
* This Slideshow is using Nivo Slider Js Script form http://dev7studios.com .
*/
// no direct access
defined('_JEXEC') or die('Restricted access');
$document =& JFactory::getDocument();

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');
    
    /*Get all params*/
    if($params->get('image_source') == 'joomla'){
        $show_title = $params->get('show_article_title',1);
        $show_intro = $params->get('show_article',1);
        $show_title_link = $params->get('show_title_link');
    }
    /*Assign all catid */
    $catid = $params->get('catid','');
    if(  $catid != '' ){
        if (! is_array ( $catid ) ) {
            $catid = preg_split ( '/,/', $catid );
        }
        $catid     =     '"' . implode ( '","', $catid ) . '"'; 
    } 
    
    $lists = modJoloSliderHelper::getList($params, $catid);
    $counter = 0;
    
    /* load css. */ 
    modJoloSliderHelper::loadCss( $params );

    /* Load JS. */
    modJoloSliderHelper::loadJs($params);
    
    if($params->get('image_source') == 'joomla') require(JModuleHelper::getLayoutPath('mod_joloslider','joomla'));
    else require(JModuleHelper::getLayoutPath('mod_joloslider','images'));
    
    //if($params->get('image_source') = 'joomla') require(JModuleHelper::getLayoutPath('mod_joloslider','joomla'));
    //else if($params->get('image_source') = 'image_dir') require(JModuleHelper::getLayoutPath('mod_joloslider','images'));
