<?php
/**
 * @copyright	Copyright (C) 2009-2012 ACYBA SARL - All rights reserved.
 * @license		http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
?>
<?php include(ACYMAILING_BACK.'views'.DS.'statsurl'.DS.'tmpl'.DS.'detaillisting.php');