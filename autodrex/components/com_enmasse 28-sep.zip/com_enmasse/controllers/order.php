<?php


jimport('joomla.application.component.controller');

class EnmasseControllerOrder extends JController
{
	
}