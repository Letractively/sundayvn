<?php

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.controller');
 
class EnmasseController extends JController
{    
    public function display($cachable = false, $urlparams = false)
    {
         parent::display();
    }
}
?>