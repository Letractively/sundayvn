
<table class="noBorder" id="top">
	<tr>
		<td style="float:left"><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=dealShow')?>"><?php echo JTEXT::_('SALE_LIST_DEAL');?></a></td>
		<td style="float:left"><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=dealAdd')?>"><?php echo JTEXT::_('SALE_ADD_DEAL');?></a></td>
		<td style="float:left"><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=merchantList')?>"><?php echo JTEXT::_('SALE_MERCHANT_LIST');?></a></td>
		<td style="float:left"><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=merchantEdit')?>"><?php echo JTEXT::_('SALE_MERCHANT_ADD');?></a></td>
        <td style="float:left"><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salereports&task=dealReport')?>">Sales Report</a></td>
      <td style="float:left"><a href="<?php echo JRoute::_('index.php?option=com_users&controller=login&task=logout&return=aHR0cDovL3JvY2tkZXNpZ25pbmcuY29tL2NhcnRhY3MvaW5kZXgucGhwL2hvbWU=')?>">Logout</a></td>
	</tr>
</table>
