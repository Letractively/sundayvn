<?php


jimport('joomla.application.component.controller');

class EnmasseControllerRss extends JController
{
	function __construct()
	{
		parent::__construct();
	}
  
	function today() 
	{
		JRequest::setVar('view', 'rss');
		parent::display();
	}
  
	function listdeal() 
	{
		JRequest::setVar('view', 'rss');
		parent::display();
	}
  
	function location() 
	{		
		JRequest::setVar('view', 'rss');
		parent::display();
	}  
  
}
?>