<?php
header('Location: html/code39.php');
?>