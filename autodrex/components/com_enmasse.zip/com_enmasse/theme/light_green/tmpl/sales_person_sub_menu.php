<table class="noBorder" id="top">
	<tr>
		<td><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=dealShow')?>"><?php echo JTEXT::_('SALE_LIST_DEAL');?></a></td>
		<td width="10" align="center"> | </td>	
		<td><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=dealAdd')?>"><?php echo JTEXT::_('SALE_ADD_DEAL');?></a></td>
		<td width="10" align="center"> | </td>	
		<td><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=merchantList')?>"><?php echo JTEXT::_('SALE_MERCHANT_LIST');?></a></td>
		<td width="10" align="center"> | </td>	
		<td><a href="<?php echo JRoute::_('index.php?option=com_enmasse&controller=salesPerson&task=merchantEdit')?>"><?php echo JTEXT::_('SALE_MERCHANT_ADD');?></a></td>
	</tr>
</table>
