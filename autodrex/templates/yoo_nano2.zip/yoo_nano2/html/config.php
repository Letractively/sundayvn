<?php

// get config
require_once(dirname(dirname(__FILE__)).'/config.php');

// get warp
$warp = Warp::getInstance();