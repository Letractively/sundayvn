<?php

// raw output
echo $content;