<?php

foreach ($modules as $module) {
	printf('<div class="grid-box width100 grid-v">%s</div>', $module);
}