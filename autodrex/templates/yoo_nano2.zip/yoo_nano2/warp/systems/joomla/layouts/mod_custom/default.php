<?php
// no direct access
defined('_JEXEC') or die;

?>

<?php echo $module->content;