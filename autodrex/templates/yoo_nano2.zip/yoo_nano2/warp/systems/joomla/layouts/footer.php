<?php
// output tracking code
echo $this['config']->get('tracking_code');